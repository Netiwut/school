
// if (process.env.NODE_ENV === "production") {
//     module.exports = require("./prod");
//   } else {
//     module.exports = require("./dev");
//   }
export const config = {
    apiKey: "AIzaSyCXyRVgH7L-Zscmda4fsUw3Z6f2IQId5ns",
    authDomain: "school-fce9a.firebaseapp.com",
    databaseURL: "https://school-fce9a.firebaseio.com",
    projectId: "school-fce9a",
    storageBucket: "school-fce9a.appspot.com",
    messagingSenderId: "288116997431"
  }