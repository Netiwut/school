import React, { Component } from 'react';
import { connect } from "react-redux";
import * as actions from "./actions";
class App extends Component {
  componentDidMount(){
    this.props.fetchStudents()
  }
  componentWillReceiveProps(np){
    if(np.students){
      console.log(np.students)
    }
  }
  render() {
    return (
      <div>
       App
      </div>
    );
  }
}
const mapStateToProps = ({getStudents}) => ({
  students: getStudents
})

// const mapDispatchToProps = dispatch => ({
//   getStudents : () =>dispatch(fetchStudents())
// })
export default connect(
  mapStateToProps,
  actions
)(App)
