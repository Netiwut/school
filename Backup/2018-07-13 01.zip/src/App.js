import React, { Component } from 'react';
import { connect } from "react-redux";
import { fetchStudents } from "./actions";
class App extends Component {
  componentDidMount(){
    this.props.getStudents()
  }
  componentWillReceiveProps(np){
    if(np.students){
      console.log(np.students)
    }
  }
  render() {
    return (
      <div>
       App
      </div>
    );
  }
}
const mapStateToProps = ({getStudents}) => ({
  students: getStudents
})

const mapDispatchToProps = dispatch => ({
  getStudents : () =>dispatch(fetchStudents())
})
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App)
