import { refStudents } from "../services/config/firebase"
import { GET_STUDENTS } from "./types"

export const fetchStudents = () => async dispath => {
    refStudents.on("value", snapshot => {
        dispath({
            type : GET_STUDENTS,
            data : snapshot.val()
        })
    })
}