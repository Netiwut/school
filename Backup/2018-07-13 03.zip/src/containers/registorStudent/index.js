import React, { Component } from 'react'

export class registorStudent extends Component {
  render() {
    return (
      <div>
        registorStudent
      </div>
    )
  }
}

export default registorStudent
